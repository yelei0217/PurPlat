package com.kingdee.eas.custom.rest;

public class InterfaceResource {
	 /**SAP �ӿڻ���URL **/
	public static final String sap_base_url ="https://admin-dev.wellekq.com/api/meiwei-resource/EAS/syncBaseData?access_token=MWJrIHED12GdwIyCLBt2nBIdWp7KEQxr&origin=EAS";

	 /**SAP SSL ֤��·��  **/
	public static final String sap_Certificate_path = "/software/xxx.keystore";
	
	 /**SAP SSL ֤��·��  **/
	public static final String sap_Certificate_pwd="123456";
}
